# README
        
## Order Summary

* Roslindale Beta Variable Display
* Roslindale Beta Display Condensed Light
* Roslindale Beta Display Condensed
* Roslindale Beta Display Condensed Medium
* Roslindale Beta Display Condensed Bold
* Roslindale Beta Text Regular
* Roslindale Beta Text Italic
* Roslindale Beta Text Bold

Order Number: 171402491
Licensee: Rolf Anders Jensen
E-mail: itsrolf@gmail.com
Domain Names: Rolf Jensen Design LLC

## License Summary

Your purchase entitles you to use the fonts according to the following limitations:

### Mini

* Up to 3 desktop workstations
* Up to 15,000 monthly unique web visitors
* Up to 1 e-book
            
Please refer to LICENSE.txt for the full terms of the license. If you would like to exceed any of these limitations, you can purchase an upgrade by contacting me at <david@djr.com>.

## Using the fonts

Please refer to INSTALL.txt for desktop installation instructions and font cache troubleshooting.

For an example of how to use the web font files via CSS @font-face, please consult the CSS file included in the web fonts folder.

Happy typesetting!

- DJR
